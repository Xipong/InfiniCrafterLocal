"""Offline exact-value dictionary encoding of complete Author capability cards.

No meaning is summarised, no parameter is removed, and no production owner is
changed. References affect documentation representation only, not authored JSON.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import hashlib
import json
from typing import Any

REF = "$catalogueRef"
TABLE = "sharedExactValues"
INSTRUCTION = (
    "Catalogue documentation uses exact shared-value references: an object with only "
    "'$catalogueRef': 'vN' means the COMPLETE value at catalog.sharedExactValues.vN. "
    "Expand references recursively when reading targets, parameters, requirements or any "
    "other card field. References can stand for objects, arrays or strings; nothing is optional "
    "or omitted by this encoding. All capability cards and their full parameter meanings, "
    "units, grammar and constraints remain available. This is documentation encoding only: "
    "write ordinary requiredJsonShape output; never emit $catalogueRef or sharedExactValues."
)


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _hash(value: Any) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _counts(value: Any, counts: Counter, values: dict) -> None:
    if isinstance(value, dict) and set(value) == {REF}:
        return
    if isinstance(value, (dict, list, str)):
        key = _json(value)
        counts[key] += 1
        values[key] = value
    if isinstance(value, dict):
        for child in value.values():
            _counts(child, counts, values)
    elif isinstance(value, list):
        for child in value:
            _counts(child, counts, values)


def _replace(value: Any, exact: str, ref_id: str) -> Any:
    if isinstance(value, dict) and set(value) == {REF}:
        return value
    if _json(value) == exact:
        return {REF: ref_id}
    if isinstance(value, dict):
        return {key: _replace(child, exact, ref_id) for key, child in value.items()}
    if isinstance(value, list):
        return [_replace(child, exact, ref_id) for child in value]
    return value


def reconstruct_catalogue(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Return original ordered cards; reject missing/cyclic/ambiguous references."""
    catalog = payload["runtimeCapabilityContract"]["catalog"]
    table = catalog[TABLE]

    def expand(value, stack=()):
        if isinstance(value, dict):
            if REF in value:
                if set(value) != {REF}:
                    raise ValueError("Reference cannot carry sibling fields")
                ref_id = value[REF]
                if ref_id in stack:
                    raise ValueError("Cyclic documentation reference")
                if ref_id not in table:
                    raise ValueError("Missing documentation reference")
                return expand(table[ref_id], (*stack, ref_id))
            return {key: expand(child, stack) for key, child in value.items()}
        if isinstance(value, list):
            return [expand(child, stack) for child in value]
        return value

    return expand(catalog["capabilities"])


def compact_payload(payload: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Greedily factor repeated exact subtrees, including full prose and grammar.

    A dictionary entry stores its exact original value once. We greedily accept
    only steps reducing complete compact JSON o200k tokens including dictionary
    overhead. Definitions may refer to later definitions; the finite DAG is
    proved by reconstruction, not assumed from IDs.
    """
    import tiktoken

    enc = tiktoken.get_encoding("o200k_base")
    tokens = lambda value: len(enc.encode(_json(value)))
    original = payload["runtimeCapabilityContract"]["catalog"]["capabilities"]
    bundle = {TABLE: {}, "capabilities": deepcopy(original)}
    steps = []
    while True:
        counts, values = Counter(), {}
        # Count within definitions but never factor the table/container itself.
        _counts(bundle["capabilities"], counts, values)
        for value in bundle[TABLE].values():
            _counts(value, counts, values)
        ref_id = f"v{len(bundle[TABLE])}"
        ref_tokens = tokens({REF: ref_id})
        candidates = sorted(
            ((key, (count - 1) * len(enc.encode(key)) - count * ref_tokens - 5)
             for key, count in counts.items() if count >= 2),
            key=lambda pair: (-pair[1], pair[0]),
        )
        accepted = None
        previous_tokens = tokens(bundle)
        for key, estimate in candidates[:12]:
            if estimate <= 0:
                break
            replaced = {
                TABLE: {k: _replace(v, key, ref_id) for k, v in bundle[TABLE].items()},
                "capabilities": _replace(bundle["capabilities"], key, ref_id),
            }
            replaced[TABLE][ref_id] = deepcopy(values[key])
            after = tokens(replaced)
            if after < previous_tokens:
                accepted = replaced
                steps.append({"id": ref_id, "occurrences": counts[key],
                              "savedTokens": previous_tokens - after})
                break
        if accepted is None:
            break
        bundle = accepted

    result = deepcopy(payload)
    catalog = result["runtimeCapabilityContract"]["catalog"]
    result["runtimeCapabilityContract"]["catalog"] = {
        key: value for key, value in catalog.items() if key != "capabilities"
    }
    result["runtimeCapabilityContract"]["catalog"].update(bundle)
    result["priorityHeader"].insert(0, INSTRUCTION)
    reconstructed = reconstruct_catalogue(result)
    if _json(reconstructed) != _json(original):
        raise AssertionError("Lossless catalogue reconstruction failed")
    audit = {
        "method": "exact repeated JSON subtree dictionary; no semantic summarisation",
        "tokenizer": "o200k_base compact JSON proxy; provider schema unchanged and excluded",
        "capabilities": len(original), "dictionaryEntries": len(bundle[TABLE]),
        "originalCatalogueSha256": _hash(original),
        "reconstructedCatalogueSha256": _hash(reconstructed),
        "orderedCompactJsonEqual": True,
        "originalPayloadTokens": tokens(payload), "compactPayloadTokens": tokens(result),
        "originalCatalogueTokens": tokens(original), "compactCatalogueBundleTokens": tokens(bundle),
        "instructionTokens": len(enc.encode(INSTRUCTION)), "steps": steps,
        "limitations": ["Reversible bytes do not prove equal model comprehension",
                       "No API billing or cache hits measured",
                       "Additional reference-reading instructions can add model error"],
    }
    audit["payloadReductionPercent"] = 100 * (1 - audit["compactPayloadTokens"] / audit["originalPayloadTokens"])
    return result, audit


if __name__ == "__main__":
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--proof", type=Path, required=True)
    args = parser.parse_args()
    if args.input:
        payload = json.loads(args.input.read_text(encoding="utf-8"))
    else:
        from infini_local.pipelines.llm_authoring_prompt import build_llm_author_payload
        payload = build_llm_author_payload({}, {}, "lossless_dictionary_measurement")
    compact, audit = compact_payload(payload)
    if args.output:
        args.output.write_text(json.dumps(compact, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    args.proof.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in audit.items() if key != "steps"}, ensure_ascii=False))
