"""Offline Live10 controlled Author study. No API calls or production changes."""
from pathlib import Path
import ast, copy, hashlib, json, sys
ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
sys.path.insert(0, str(PROJECT / 'LocalGenerator'))
sys.path.insert(0, str(ROOT))
from selection_engine import build_selector_packet, build_author_variant
from infini_local.pipelines.llm_authoring_prompt import build_llm_author_payload
from infini_local.pipelines.author_item_contract import author_item_provider_response_schema, project_provider_author_item_to_local
from infini_local.core.llm_json_tools import parse_first_valid_llm_json
from infini_local.core.runtime_authoring.program_schema import assert_bounded_author_input
from infini_local.core.runtime_authoring.validator import validate_runtime_program
from infini_local.core.runtime_authoring.compiler import compile_runtime_program

ARMS = ['native','groups_full','groups','capabilities_full','capabilities']
BRIEF = ('Controlled preservation study. Design one coherent useful hybrid from both exact parent dossiers. '
 'Preserve as many useful primary AND secondary parent functions as the catalogue can actually execute, '
 'including tool action, ammunition, placement, equipped effects, controls, child entities and event effects where relevant. '
 'Use multiple explicit bindings/functions when needed. Invented additions may complement source identity, '
 'but do not silently substitute prose for an executable source function. Distinguish unsupported source mechanics '
 'from functions deliberately changed for the design; do not invent source facts. The optional selectionIntent is advisory. '
 'All catalogue IDs remain legal. Never fabricate an unknown parameter; no extra documentation retrieval is available. '
 'Return the complete authored item, not just runtimeProgram. This is one first answer without feedback or Repair.')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p, v):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def compact(v): return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def native_ingress(path,response_format=None):
 raw=Path(path).read_text(encoding='utf-8')
 parsed=parse_first_valid_llm_json(raw)
 if not isinstance(parsed,dict):raise TypeError('Author root must be an object')
 assert_bounded_author_input(parsed,authored_only=False)
 fmt=response_format or {'type':'json_schema','json_schema':{'schema':read(ROOT/'provider_schema.json')}}
 return parsed,project_provider_author_item_to_local(parsed,response_format=fmt)
def tid(arm,case): return hashlib.sha256(f'live10-v1/{arm}/{case}'.encode()).hexdigest()[:12]
def literals():
 path=PROJECT/'LocalGenerator/infini_local/pipelines/llm_authoring_pipeline.py'
 return {n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(path.read_text()).body
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)
  and n.targets[0].id in {'_AUTHOR_SYSTEM','_AUTHOR_CACHE_PREFIX_KEYS'}}

def save_trial(arm,case,payload):
 ident=tid(arm,case)
 schema=read(ROOT/'provider_schema.json')
 wrapper={'system':literals()['_AUTHOR_SYSTEM'],'payload':payload,
  'providerResponseFormat':{'type':'json_schema','json_schema':{'name':'infini_low_level_runtime_author','strict':True,'schema':schema}},
  'studyNote':'The exact provider schema is supplied as reading material; this subagent session does not enforce provider constrained decoding.'}
 # Compact file avoids wasting read context on indentation.
 p=ROOT/'packets'/f'{ident}.json';p.parent.mkdir(exist_ok=True)
 p.write_text(compact(wrapper)+'\n',encoding='utf-8')
 return {'id':ident,'arm':arm,'case':case,'packetSha256':sha(p)}

def prepare():
 if (ROOT/'protocol.json').exists():raise FileExistsError('Frozen study exists; prepare a separate directory, never overwrite first answers.')
 panel=read(PROJECT/'toolbox/fixtures/panels/live10-midgame.json')
 dump=PROJECT/'toolbox/fixtures/parents/live10-midgame.jsonl'
 items={r['internalName']:r for line in dump.read_text().splitlines() if line.strip() for r in [json.loads(line)]}
 write(ROOT/'provider_schema.json',author_item_provider_response_schema())
 trials=[]
 for case in panel['cases']:
  name=case['case']; payload=build_llm_author_payload(items[case['itemA']],items[case['itemB']],f'live10_study_{name}')
  payload['experimentBrief']=BRIEF
  write(ROOT/'sources'/f'{name}.json',payload)
  trials.append(save_trial('native',name,payload))
  for mode in ('groups','capabilities'):
   write(ROOT/'selector_packets'/mode/f'{name}.json',build_selector_packet(payload,mode,policy='selected_only'))
 write(ROOT/'protocol.json',{'schema':'ifc.live10-selection-study.v1','mainCommit':'c2899c79fe990583f4be8001721b6ba2f3a438c9',
  'experimentCommit':'c84653cc8af56a7ca3f47c3b9cd6a97000356417','panelSha256':sha(PROJECT/'toolbox/fixtures/panels/live10-midgame.json'),
  'parentsSha256':sha(dump),'cases':panel['cases'],'arms':ARMS,'trials':trials,'commonBrief':BRIEF,
  'generation':'Fresh GPT-6 Luna high sessions per Author; two selector sessions each batch ten cases. One extra selector stage per two-stage design.',
  'controls':'Within mode, full and reduced receive identical intent, parents, global instructions and complete provider schema. Only documentation detail/authority sentence differs.',
  'limits':['one replicate per case/arm','subagent tool-read execution, not provider API pipeline','schema shown, no constrained decoding','no paid usage/cache/latency/hidden reasoning measurements','no Visual/VFX/image/Repair generation','no Terraria smoke']})

def assemble():
 protocol=read(ROOT/'protocol.json');trials=[t for t in protocol['trials'] if t['arm']=='native']
 for c in protocol['cases']:
  case=c['case']; source=read(ROOT/'sources'/f'{case}.json')
  for mode in ('groups','capabilities'):
   selection_path=ROOT/'cost_selections'/mode/f'{case}.json'
   if not selection_path.exists():continue
   choice=read(selection_path)
   for full in (False,True):
    arm='route_'+mode+('_full' if full else '')
    packet,audit=build_author_variant(source,mode,{**choice,'fullCatalog':True} if full else choice,policy='selected_only')
    if not full and not choice['fullCatalog']:
     i=next(i for i,x in enumerate(packet['priorityHeader']) if x.startswith('Every capability in catalog.capabilities'))
     packet['priorityHeader'][i]='Use only capabilities present in runtimeCapabilityContract.catalog.capabilities or runtimeCapabilityContract.indexOnlyCapabilities.'
    write(ROOT/'audit'/f'{tid(arm,case)}.json',audit)
    trials.append(save_trial(arm,case,packet))
   # Reuse the same frozen selector answer for conservative-policy SIZE audit only.
   packet,audit=build_author_variant(source,mode,choice,policy='non_drivers')
   write(ROOT/'conservative_packets'/mode/f'{case}.json',packet)
 if (ROOT/'compact_catalogue.py').exists():
  from compact_catalogue import compact_payload
  for c in protocol['cases']:
   packet,audit=compact_payload(read(ROOT/'sources'/f"{c['case']}.json"))
   trials.append(save_trial('compact',c['case'],packet))
   write(ROOT/'audit'/f"{tid('compact',c['case'])}.json",audit)
  if 'compact' not in protocol['arms']:protocol['arms'].append('compact')
 protocol['trials']=trials;write(ROOT/'protocol.json',protocol)

def evaluate(protocol_name='protocol.json', output_name='results.json'):
 import tiktoken, jsonschema
 enc=tiktoken.get_encoding('o200k_base');tok=lambda v:len(enc.encode(compact(v)))
 protocol=read(ROOT/protocol_name);rows=[]
 snapshot=read(ROOT/'free_choice_snapshot.json') if protocol_name=='free_choice_protocol.json' and (ROOT/'free_choice_snapshot.json').exists() else None
 for t in protocol['trials']:
  packet=read(ROOT/'packets'/f"{t['id']}.json");p=packet['payload'];o=ROOT/'outputs'/f"{t['id']}.json"
  row={**t,'authorPayloadTokensProxy':tok(p),'schemaTokensProxy':tok(packet['providerResponseFormat']),
   'authorContentPlusSchemaProxy':tok(p)+tok(packet['providerResponseFormat'])+len(enc.encode(packet['system'])),
   'detailedCapabilities':len(p['runtimeCapabilityContract']['catalog']['capabilities'])}
  if t['arm'] not in ('native','compact'):
   mode=t['arm'].removeprefix('route_').removesuffix('_full');case=t['case'];cost=t['arm'].startswith('route_')
   row['selectorInputTokensProxy']=tok(read(ROOT/('cost_selector_packets' if cost else 'selector_packets')/mode/f'{case}.json'))
   row['selectorOutputTokensProxy']=tok(read(ROOT/('cost_selections' if cost else 'selections')/mode/f'{case}.json'))
   row['conservativeAuthorTokensProxy']=tok(read(ROOT/'conservative_packets'/mode/f'{case}.json')) if cost else tok(p)
  if o.exists() and (snapshot is None or t['id'] in snapshot['frozenIds']):
   row['outputSha256']=sha(o)
   try:
    try:read(o);row['rawStrictJsonValid']=True
    except ValueError:row['rawStrictJsonValid']=False
    parsed,doc=native_ingress(o,packet['providerResponseFormat']);write(ROOT/'canonical'/f"{t['id']}.json",doc)
    row['nativeParsed']=True;row['nullableProjectionChanged']=doc!=parsed
    row['directRawCanonicalValid']=validate_runtime_program(parsed)['ok']
    report=validate_runtime_program(doc);row.update(valid=report['ok'],errors=report.get('errors',[]),outputTokensProxy=tok(parsed))
    se=list(jsonschema.Draft202012Validator(packet['providerResponseFormat']['json_schema']['schema']).iter_errors(parsed))
    row['providerSchemaValid']=not se
    row['providerSchemaErrorCount']=len(se)
    row['providerSchemaErrors']=[{'path':list(e.absolute_path),'validator':e.validator,'message':e.message[:250]} for e in se]
    row['usedCapabilities']=sorted({c.get('fn') for c in doc.get('runtimeProgram',{}).get('calls',[])})
    detailed={c.get('fn') for c in p['runtimeCapabilityContract']['catalog']['capabilities']}
    row['indexOnlyUsed']=sorted(set(row['usedCapabilities'])-detailed)
    if report['ok']:
     compiled=compile_runtime_program(doc);write(ROOT/'compiled'/f"{t['id']}.json",compiled);row['compiled']=True
   except Exception as e:row.update(valid=False,evaluationError=f'{type(e).__name__}: {e}')
  else:
   row['notRun']=True
   if snapshot is not None:row['stoppedBeforeAssignment']=True
  rows.append(row)
 write(ROOT/output_name,{'rows':rows,'tokenizer':'o200k_base compact serialization proxy; not billing','outputsFrozen':sum('outputSha256'in r for r in rows)})
 print(compact({'trials':len(rows),'outputs':sum('outputSha256'in r for r in rows),'valid':sum(r.get('valid',False) for r in rows)}))

def evaluate_free_choice():evaluate('free_choice_protocol.json','free_choice_results.json')
def verify_frozen():
 from compact_catalogue import reconstruct_catalogue
 p=read(ROOT/'protocol.json');rs=read(ROOT/'results.json')['rows'];checks=0
 assert len(p['trials'])==len(rs)==60
 assert sha(ROOT/'frozen_parents.jsonl')==p['parentsSha256'];checks+=1
 assert sha(ROOT/'frozen_panel.json')==p['panelSha256'];checks+=1
 for t in p['trials']:
  path=ROOT/'packets'/f"{t['id']}.json";assert sha(path)==t['packetSha256'];checks+=1
  w=read(path);s=read(ROOT/'sources'/f"{t['case']}.json")
  assert w['providerResponseFormat']['json_schema']['schema']==read(ROOT/'provider_schema.json');checks+=1
  assert w['payload']['parents']==s['parents'];checks+=1
  if t['arm']=='compact':assert reconstruct_catalogue(w['payload'])==s['runtimeCapabilityContract']['catalog']['capabilities'];checks+=1
 for t in rs:assert sha(ROOT/'outputs'/f"{t['id']}.json")==t['outputSha256'];checks+=1
 for id,h in read(ROOT/'free_choice_snapshot.json')['hashes'].items():assert sha(ROOT/'outputs'/f'{id}.json')==h;checks+=1
 for x in read(ROOT/'selector_validation.json')['rows']:
  d='selections' if x['condition']=='free' else 'cost_selections'
  assert sha(ROOT/d/x['mode']/f"{x['case']}.json")==x['selectionSha256'];checks+=1
 print(compact({'frozenChecksPassed':checks,'mainOutputs':60,'freeChoiceSnapshot':16,'selectorDecisions':40,'allCurrentPacketSchemasIdentical':True}))
if __name__=='__main__':globals()[sys.argv[1]]()
