"""Read-only catalogue audit. No provider calls or game execution."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / 'LocalGenerator'))
from infini_local.core.runtime_authoring.capability_registry import CAPABILITY_REGISTRY as R
from infini_local.core.runtime_authoring.validator import validate_runtime_program
from infini_local.core.runtime_authoring.compiler import compile_runtime_program

PRIOR = 'c84653cc8af56a7ca3f47c3b9cd6a97000356417'
ART = 'docs/development/experiments/capability_selection_2026-10-22'
def prior_bytes(rel): return subprocess.check_output(['git','show',f'{PRIOR}:{ART}/{rel}'],cwd=ROOT)
def prior_json(rel): return json.loads(prior_bytes(rel))
BASE = '57c58d50504a7c69712e5843fa392b9a39800537'
HEAD = 'c2899c79fe990583f4be8001721b6ba2f3a438c9'

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def command(*args): return subprocess.check_output(args, cwd=ROOT, text=True)

paths = [
'LocalGenerator/infini_local/core/runtime_authoring/capability_registry.py',
'LocalGenerator/infini_local/core/runtime_authoring/validator.py',
'LocalGenerator/infini_local/core/runtime_authoring/compiler.py',
'LocalGenerator/infini_local/pipelines/author_item_contract.py',
'ModSources/InfiniCrafterLocal/Content/Projectiles/GeneratedProjectile.Executors.cs',
'ModSources/InfiniCrafterLocal/Content/Projectiles/GeneratedProjectile.cs',
'ModSources/InfiniCrafterLocal/Content/Projectiles/GeneratedProjectile.DamageGate.cs',
'ModSources/InfiniCrafterLocal/Content/Projectiles/GeneratedProjectile.RuntimeEvents.cs',
'ModSources/InfiniCrafterLocal/Content/Items/GeneratedItem.Use.cs',
'ModSources/InfiniCrafterLocal/Content/Items/GeneratedItem.Equipment.cs',
]
source_identity=[]
for path in paths:
 old=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=ROOT)
 current=(ROOT/path).read_bytes()
 source_identity.append({'path':path,'baseSha256':sha(old),'currentSha256':sha(current),'byteIdentical':old==current})

proofs=[]
for rel in ['outputs/capabilities/trap.json','outputs/groups/tool.json','outputs/capabilities/tool.json','outputs/baseline/tool.json','outputs/baseline/musket.json','followup/outputs/325c90f89e75.json']:
 data=prior_bytes(rel); d=json.loads(data);v=validate_runtime_program(d)
 proof={'source':f'{PRIOR}:{ART}/{rel}','sha256':sha(data),'valid':v['ok'],'errors':v.get('errors',[])}
 if v['ok']:
  w=compile_runtime_program(d);proof['compiled']=True
  if rel.endswith('325c90f89e75.json'):
   proof['childDamageConfiguration']=[{'id':e['id'],'damage':e.get('damage'),'events':e.get('events',[])} for e in w['runtimeProgram']['entities']]
 proofs.append(proof)

# A hand-authored counterexample, never an Author success or repaired generation.
conflict=prior_json('followup/outputs/325c90f89e75.json')
body=next(e['id'] for e in conflict['runtimeProgram']['entities'] if e['kind']=='item_body')
conflict['runtimeProgram']['calls'].append({'id':'synthetic_ammo_role_witness','target':body,'fn':'configure_vanilla_ammo_item','params':{'ammoCategory':'arrow','projectileId':91,'shootSpeedContributionBlocksPerSecond':0,'notAmmo':False}})
role_validation=validate_runtime_program(conflict)

parents=[json.loads(row) for row in (ROOT/'toolbox/fixtures/parents/live10-midgame.jsonl').read_text(encoding='utf-8').splitlines()]
compact_parents=[]
for p in parents:
 raw=p.get('directProjectileRaw') or {}
 compact_parents.append({k:p[k] for k in ['internalName','tooltipLines','damage','damageClass','accessory','material','consumable','defense','createTile','placeStyle','pickPower','manaCost','ammo','useAmmo','buffType','buffTime']}|{'directProjectile':{k:raw.get(k) for k in ['internalName','type','friendly','minion','sentry','minionSlots','aiStyle','penetrate','timeLeft','tileCollide','extraUpdates']},'rawTopLevelKeys':list(p),'rawProjectileKeys':list(raw)})

result={
 'schema':'ifc.live10.catalogue-audit.v1','base':BASE,'currentRuntimeHead':HEAD,'capabilityCount':len(R),
 'sourceIdentity':source_identity,'allInspectedSourcesIdentical':all(r['byteIdentical'] for r in source_identity),
 'rawParentSha256':sha((ROOT/'toolbox/fixtures/parents/live10-midgame.jsonl').read_bytes()),
 'replayedOriginalWitnesses':proofs,
 'registryWitnesses':{
  'generatedBuffParameterNames':list(R['apply_generated_buff_on_use'].params),
  'heldDefenseSupportedByGeneratedBuff':'defensePoints' in R['apply_generated_buff_on_use'].params,
  'accessoryParameterNames':list(R['configure_accessory'].params),
  'nativeMinionCapabilityCandidates':[n for n in R if 'minion' in n.lower()],
  'nativeSentrySupported':'set_projectile_sentry' in R,
  'ammoRoleExclusiveGroups':{n:R[n].exclusive_group for n in ['configure_weapon_ammo','configure_vanilla_ammo_item']},
  'syntheticAmmoRoleConflict':{'source':'manual synthetic counterexample; not a model answer','valid':role_validation['ok'],'errors':role_validation.get('errors',[])},
  'buffActivationRequirement':[{'kind':r.kind,'message':r.message} for r in R['apply_generated_buff_on_use'].requirements],
 },
 'parents':compact_parents,
 'limits':['No Terraria execution','No new C# test run','Static source inspection and canonical Python validation/compiler only','Original witnesses are frozen older outputs; replayed on current runtime','Source tooltip prose is not an exact native behavioral specification'],
}
(Path(__file__).parent/'catalogue_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'allInspectedSourcesIdentical':result['allInspectedSourcesIdentical'],'witnesses':len(proofs),'rawParentSha256':result['rawParentSha256'],'ammoConflictRejected':not role_validation['ok'],'ammoConflictErrors':role_validation.get('errors',[])},ensure_ascii=False))
