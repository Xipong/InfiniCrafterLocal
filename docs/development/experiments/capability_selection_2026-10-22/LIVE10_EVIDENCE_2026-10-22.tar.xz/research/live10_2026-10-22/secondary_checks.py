"""Narrow source-utility projections, not a complete gameplay quality judge."""
from study import ROOT,read,write,native_ingress

def project(doc,case):
 p=doc.get('runtimeProgram',{});calls=p.get('calls',[]);bindings=p.get('bindings',[])
 body=next((x['id'] for x in p.get('entities',[]) if x.get('kind')=='item_body'),None)
 def find(fn):return [c for c in calls if c.get('fn')==fn and c.get('target')==body]
 equipped=any(b.get('input')=='equipped' and b.get('action',{}).get('kind')=='equip_passive' and b['action'].get('targetId')==body for b in bindings)
 ac=[c['params'] for c in find('configure_accessory')] if equipped else []
 def effect(key,predicate=lambda v:v is True):return any(predicate(x.get(key,0)) for x in ac)
 def placement(tile,style):
  return any(c.get('fn')=='configure_tile_placement' and c.get('target')==body
   and c.get('params',{}).get('tileId')==tile and c['params'].get('placeStyle')==style
   and any(b.get('action',{}).get('kind')=='place_item' and b['action'].get('targetId')==body
    and b['action'].get('placementCallId')==c.get('id') for b in bindings) for c in calls)
 if case=='crystal_repeater':return {'native_crystal_placement':placement(129,0)}
 if case=='radiant_forge':return {'native_anvil_placement':placement(134,1)}
 if case=='precision_titanium':return {'native_pick_configuration_and_primary':any(c['params'].get('pickPower',0)>0 for c in find('configure_tool')) and any(b.get('input')=='primary_use' and b.get('action',{}).get('kind')!='place_item' for b in bindings), 'equipped_wire_vision':effect('wireVision')}
 if case=='frost_obsidian_guard':return {k:effect(k,(lambda v:v>0) if k in {'moveSpeedBonusPercent','accRunSpeedBlocksPerSecond','rocketBoots','defensePoints'} else (lambda v:v is True)) for k in ['moveSpeedBonusPercent','accRunSpeedBlocksPerSecond','rocketBoots','iceSkate','noKnockback','fireWalk','defensePoints']}
 return {}

def run():
 rows=[]
 for t in read(ROOT/'protocol.json')['trials']:
  path=ROOT/'outputs'/f"{t['id']}.json"
  if path.exists():
   try:rows.append({**t,'checks':project(native_ingress(path)[1],t['case'])})
   except (ValueError,TypeError,KeyError) as e:rows.append({**t,'parseOrShapeError':str(e)})
 write(ROOT/'secondary_checks.json',{'scope':'Narrow evidence-based secondary function projection; must also pass canonical validation/compilation. Does not establish game behavior or complete source preservation.','rows':rows})

if __name__=='__main__':run()
