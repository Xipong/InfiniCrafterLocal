# Live10: заранее зафиксированная рубрика сохранения полезных функций

Зафиксировано до чтения ответов Author. База — `c2899c79fe990583f4be8001721b6ba2f3a438c9`, точные 20 исторических родителей из `toolbox/fixtures/parents/live10-midgame.jsonl`. Это рубрика эксперимента с общим заданием сохранить полезные основные и вторичные функции, а не требование production Author буквально скопировать vanilla AI.

## Правила оценки

Каждый ответ оценивается независимо по: (1) canonical schema/validator/compiler; (2) достижимому исполнению функций ниже; (3) правдивости заявленных механик; (4) потерям полезных функций. Валидность сама по себе не означает сохранения функций. Один запуск на case/arm не является оценкой надёжности модели.

Для каждой функции используются значения **preserved**, **partial/deliberately transformed**, **lost**, **source-blocked**, **catalogue-blocked**, **not established**. Отдельно учитываются основные и вторичные функции. Нельзя превращать source/catalogue-blocked в ошибку селектора или засчитывать обещание в тексте как исполнение. Намеренная новая механика допустима, но не делает исчезнувшую независимую полезную функцию сохранённой. Изменение численных damage/tempo ради композиции не считается потерей само по себе.

Исполнение устанавливается по ссылкам binding → entity → event/controller descendants и compiled wire. Положительные параметры должны действительно включать эффект; пустой вызов/нейтральный параметр не считаются доказательством. Учитываются общий `item_body.on_use` для обоих активных inputs, подавление движения контроллером, damage gate ребёнка, ограничения времени жизни и совокупных spawn budgets. Все недоказанные выводы о полном игровом поведении отмечаются как такие; Terraria не запускается.

## Наблюдаемые функции и проверки

| Case | Основные проверяемые функции | Вторичные функции и точные условия | Границы вывода |
|---|---|---|---|
| night_missile | Рабочая близкая melee-взаимодействие от NightsEdge; управляемый/направляемый магический снаряд от MagicMissile | Оба взаимодействия должны иметь достижимый ввод/producer; каналирование должно реально поддерживать выбранный cursor-controller | `noMelee=true` у NightsEdge не означает отсутствие melee-функции: родитель использует отдельный melee projectile. Точная vanilla AI не наследуется. Cursor-hover с возвратом — приближение, не точная MagicMissile с её поведением после отпускания |
| crystal_repeater | Достижимая ranged-стрельба с реальным расходом arrow ammo | Независимое native размещение CrystalShard: tileId=129, placeStyle=0, executed place_item binding | Нельзя приписывать CrystalShard отсутствующий в дампе эффект дробления. Только карточка placement без binding не сохраняет размещение |
| shadow_frost | Достижимая projectile-атака, сохраняющая осмысленную связь с метательным ножом и ледяным выстрелом | On-hit shadow-flame — наблюдаемый tooltip, но exact status ID в frozen facts отсутствует | ShadowFlameKnife.buffType=0; нельзя угадывать buffId. Frostbrand tooltip обещает ледяной снаряд, не frostburn: обязательного frostburn-теста нет |
| rain_spiders | Автономный атакующий помощник от SpiderStaff; дождь отдельных повреждающих снарядов от NimbusRod | Обе функции должны исполняться; повторяющийся дождь должен иметь достижимые damaging children, положительный интервал и совместимый lifetime/budget | `damageClass=summon` и имя spider не создают native minion, minion-slot upkeep или singleton. Каталог допускает помощника/ограничение copies, но не полную native minion lifecycle. Контроллер target_and_fire неподвижен |
| ichor_spider_queen | Развёртываемая стреляющая сущность с реальными дочерними снарядами | Native sentry registration поддерживается явно: set_projectile_sentry.enabled=true; без него не засчитывать native maxTurrets lifecycle. Отдельно отмечается defense-reduction signature | GoldenShower tooltip обещает снижение защиты, но buffType=0 и exact inflicted BuffID отсутствует. Полное сохранение Ichor нельзя доказывать выдуманным ID |
| holy_storm | Ranged arrows, созданные сверху и действительно летящие к зоне цели; фактическое потребление arrow ammo | Попадание порождает отдельные падающие damaging children: достижимый on_hit, правильная позиция/скорость и включённый child damage | HolyArrow как самостоятельная ammo-role — отдельная исходная полезность. configure_weapon_ammo и configure_vanilla_ammo_item взаимно исключаются на одном item: потерю одной роли отмечать catalogue-blocked, а не ошибкой сокращения docs |
| precision_titanium | Настоящее native mining: configure_tool с pickPower>0 плюс пригодный активный native input | MechanicalLens wire vision: configure_accessory.wireVision=true и equipped passive binding. Mining projectile не заменяет native mining | Parent pickPower=190 — источник для масштаба, не обязательное численное равенство. OreSense не эквивалентен wireVision; held и equipped — разные условия |
| frost_obsidian_guard | Рабочая экипируемая мобильность: движение, native sprint и rocket flight | Отдельные checks: moveSpeed bonus (источник +8%), accRunSpeed>0, rocketBoots>0, iceSkate=true, noKnockback=true, fireWalk=true, defensePoints>0; всё достижимо через equipped | Все эти tooltip/defense функции доступны в configure_accessory. waterWalk/lavaImmune не заменяют fireWalk. Jump bonus не доказывает rocket flight; один speed bonus не доказывает все три boot-функции |
| radiant_forge | Native placeable crafting station: tileId=134, placeStyle=1 и executed place_item binding | Полезное light-inspired дополнение допустимо как новая авторская механика; при наличии свет проверяется отдельно и должен исполняться в заявленном placed/held scope | SoulofLight — материал с тематическим tooltip; дамп не утверждает свет/баф/бой. Отсутствие придуманного света не является потерей исходной функции. Native размещение anvil сохраняет native station semantics по коду, без game smoke это source/code inference |
| meteor_star_cannon | Реальный fallen_star ammo расход и повреждающая ranged-стрельба | Независимая meteor-like атака из верхней позиции с падающим damaging projectile; отдельно mana-семантика, если заявлена | Parent MeteorStaff raw tooltip локализован как «Показывает метеоры», projectile AI сам не исполняется. Нельзя считать одну только текстуру/имя метеора skyfall-механикой. Стоимость ammo/mana проверяется по фактическому item-wide контракту, не по prose отдельных modes |

## Слепое ревью

Сначала ревьюер получает нейтральные trial IDs и frozen ответы, exact sources и эту рубрику, без arm/selector/audit/агрегатов. Он записывает evidence paths (binding/call/entity IDs) для каждого preserved/lost/blocked. Затем открываются arms и matched пары. Для спорных случаев — отдельный разбор C# consumer. После открытия arms нельзя молча менять рубрику; исправление scorer раскрывается отдельно, применяется ко всем arms и не изменяет raw outputs.

## Консервативный non_drivers: измеренная нижняя граница стоимости

Read-only измерение: текущий `build_llm_author_payload(rawA, rawB, case)` для 10 пар; без дополнительного brief. Импортированы неизменённые `build_selector_packet`, `build_author_variant`, `catalog_revision` из PR138 (`c84653c`). JSON сериализован `ensure_ascii=False,separators=(',', ':')`; tokenizer `o200k_base`. Для обоих modes selection содержит `selected=[]`, `fullCatalog=false`, `intent=''`, policy=`non_drivers`. Это искусственная нижняя граница, не ответ selector и не готовая работоспособная композиция.

| Среднее за 10 cases | Proxy tokens |
|---|---:|
| Native full Author payload | 43049.6 |
| Минимальный reduced Author | 40124.6 |
| Максимальная возможная экономия Author до реальных movement/controller selections | 2925.0 (6.795%) |
| Groups selector input | 18442.6 |
| Exact selector input | 18784.6 |
| Groups: selector + минимальный Author | 58567.2 (+36.04%) |
| Exact: selector + минимальный Author | 58909.2 (+36.84%) |

Reserve содержит 50/73 capabilities, positive dependency closure расширяет его до 51 подробной карточки даже при пустом выборе. Реальный непустой selector может только увеличить этот минимум, кроме явного fullCatalog, который возвращает полный Author. Selector output, скрытый reasoning, обвязка provider, response schema и cache accounting здесь не учтены; одинаковая schema Author сократит относительные проценты и не устранит абсолютный добавочный input. При равной цене некешированного input этот вариант не окупается даже на нижней границе; при разных ценах/кеше вывод требует отдельного расчёта.
