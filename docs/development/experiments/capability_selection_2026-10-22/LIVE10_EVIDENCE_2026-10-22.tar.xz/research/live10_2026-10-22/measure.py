"""Reproducible offline sizes and hypothetical cache/price thresholds."""
from study import ROOT, read, write, literals, compact
from collections import defaultdict
import hashlib, statistics, tiktoken
from infini_local.core.llm_prompt_cache import with_instruction_segments

enc=tiktoken.get_encoding('o200k_base')
tok=lambda v:len(enc.encode(compact(v)))
mean=statistics.mean
def common(seqs):
 return next((i for i,vals in enumerate(zip(*seqs)) if len(set(vals))!=1),min(map(len,seqs)))

def run():
 protocol=read(ROOT/'protocol.json');lit=literals();rows=[];groups=defaultdict(list)
 for t in protocol['trials']:
  w=read(ROOT/'packets'/f"{t['id']}.json");p=w['payload']
  request=with_instruction_segments({'messages':[{'role':'system','content':w['system']},{'role':'user','content':compact(p)}]},p,lit['_AUTHOR_CACHE_PREFIX_KEYS'])
  dev=next(m['content'] for m in request['messages'] if m['role']=='developer')
  usr=next(m['content'] for m in request['messages'] if m['role']=='user')
  row={**t,'authorPayload':tok(p),'authorStatic':len(enc.encode(dev)),'authorDynamic':len(enc.encode(usr)),
       'responseFormat':tok(w['providerResponseFormat']),'system':len(enc.encode(w['system'])),
       'staticHash':hashlib.sha256(dev.encode()).hexdigest()}
  row['messageContentPlusResponseFormat']=row['system']+row['authorStatic']+row['authorDynamic']+row['responseFormat']
  if t['arm'] not in ('native','compact'):
   mode=t['arm'].removeprefix('route_').removesuffix('_full');s=read(ROOT/'cost_selector_packets'/mode/f"{t['case']}.json")
   row['selectorInput']=tok(s);row['selectorStatic']=tok({k:v for k,v in s.items() if k!='context'})
   row['selectorDynamic']=row['selectorInput']-row['selectorStatic']
   row['selectorOutput']=tok(read(ROOT/'cost_selections'/mode/f"{t['case']}.json"))
   row['conservativeAuthor']=tok(read(ROOT/'conservative_packets'/mode/f"{t['case']}.json"))
  groups[t['arm']].append((row,enc.encode(dev)));rows.append(row)
 aggregates={}
 for arm,vals in groups.items():
  rs=[x[0] for x in vals]
  a={k:mean(r[k] for r in rs) for k in rs[0] if isinstance(rs[0][k],(int,float))}
  a['distinctStaticSets']=len({r['staticHash'] for r in rs});a['crossCaseCommonStaticPrefix']=common([x[1] for x in vals])
  aggregates[arm]=a
 b=aggregates['native'];economics={}
 for arm in ('route_groups','route_capabilities'):
  a=aggregates[arm];saving=b['authorStatic']+b['authorDynamic']-a['authorStatic']-a['authorDynamic']
  # Cached multiplier .1 is an explicit hypothetical, not an API price.
  warmSaving=.1*(b['authorStatic']-a['authorStatic'])+b['authorDynamic']-a['authorDynamic']
  selWarm=.1*a['selectorStatic']+a['selectorDynamic']
  economics[arm]={'bothColdSelectorPriceRatioThreshold':saving/a['selectorInput'],
   'authorStaticWarmSelectorColdThreshold':warmSaving/a['selectorInput'],
   'bothStaticWarmThreshold':warmSaving/selWarm,
   'bothColdInputSum':a['authorPayload']+a['selectorInput'],
   'bothColdInputSumVsNativePercent':100*((a['authorPayload']+a['selectorInput'])/b['authorPayload']-1)}
 write(ROOT/'measurement.json',{'rows':rows,'means':aggregates,'hypotheticalEconomics':economics,
  'assumptions':['o200k_base proxy, no actual API billing/cache/latency','Author response_format is identical in all arms and cancels in absolute savings; provider may account differently',
   'Cache scenarios assume developer/static exact sets already warm, cached multiplier .1; no measured hit rate',
   'Selector static split hypothetical: there is no production selector request/cache builder',
   'Threshold uses input only; selector output/reasoning, changed Author outputs, retries and repair costs excluded',
   'Cross-case shared prefix is not maximum reusable prefix for a repeated identical selected set']})
 print(compact({'means':aggregates,'economics':economics}))

if __name__=='__main__':run()
