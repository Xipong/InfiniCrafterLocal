# Frozen historical Live10 study evidence

Read the two delivered reports first. This is offline research, not production routing or an HTTP/game run.

70 raw first Author answers (60 complete primary trials plus10 additional free-choice diagnostics),40 selector decisions,3 independent blinded reviews. All test Authors fresh GPT-6 Luna high; selectors batches5. Old42 answers are referenced by git commit c84653c and replayed, not duplicated here.

From repository root with frozen runtime code (see protocol.json), after extracting this bundle:

```
python research/live10_2026-10-22/study.py verify_frozen
python research/live10_2026-10-22/study.py evaluate
python research/live10_2026-10-22/secondary_checks.py
python research/live10_2026-10-22/measure.py
```

Requires jsonschema and tiktoken. No API/network or model calls. `prepare` refuses to overwrite a frozen protocol. Evaluation uses production first-valid JSON parser plus the exact declared provider nullable projection before validator/compiler. Raw files never change. Canonical/compiled files are derived artifacts, not repaired answers. Do not call syntax-repair helpers to change the primary result.

free_choice_protocol.json is the stopped original design. free_choice_snapshot.json fixes exactly16 outputs present at the pause;6native/compact answers are reused by the later comparison. Do not retroactively count later baseline answers as new free-choice trials.20/20 free-choice selections chose fullCatalog=true. protocol.json documents forced-selection amendment made before that condition's outputs. New40 routed Author packets use distinct IDs.

preregistered_rubric.md predates Author review. semantic_summary.json is a DERIVED descriptive complete-retention summary after blind review, not a newly preregistered reliability endpoint. Source/catalogue-blocked effects and invented placed light are excluded; partial transformations are not complete retention. Reviewer corrections (native speed override, positive-gravity vertical fall, nullable ingress) are disclosed in report/review notes. pre_ingress_evaluation.json is an incomplete superseded analysis snapshot, never the final score.

measurement.json describes proxy reconstructed wire, not actual subagent billed tokens. .1cached multiplier is hypothetical. schema given for reading, no constrained decoding. The base Author system omitted environment suffix and provider nullable instruction; native ingress is evaluated accurately but HTTP-production error frequencies are unmeasured. No Visual/VFX/image/Repair generation or new item game smoke. Existing383native CPU CI is separately evidenced in verification.json.

Input packet hashes,40selection hashes,70output hashes and exact parent/roster SHA are recorded. Compact full catalogues expand exactly; full index/schema availability is not proof of quality for all73caps (new outputs used29).
